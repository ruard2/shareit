import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:math';

class GroepBeherenScherm extends StatefulWidget {
  const GroepBeherenScherm({super.key});

  @override
  State<GroepBeherenScherm> createState() => _GroepBeherenSchermState();
}

class _GroepBeherenSchermState extends State<GroepBeherenScherm> {
  List<dynamic> gebruikers = [];

  @override
  void initState() {
    super.initState();
    _laadGebruikers();
  }

  Future<void> _laadGebruikers() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString('user_id');

      final response = await http.get(
        Uri.parse('http://10.0.2.2:8000/gebruikers/groep'),
        headers: {
          'Content-Type': 'application/json',
          'user-id': userId ?? '',
        },
      );

      if (response.statusCode == 200) {
        setState(() {
          gebruikers = json.decode(response.body);
        });
      } else {
        print('Fout bij laden van groep: ${response.statusCode}');
      }
    } catch (e) {
      print('Fout bij ophalen groep: $e');
    }
  }


  Future<void> _verwijderGebruiker(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bevestigen'),
        content: const Text('Weet je zeker dat je deze gebruiker wilt verwijderen?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuleren')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Verwijderen')),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        final response = await http.delete(Uri.parse('http://10.0.2.2:8000/gebruikers/$id'));
        if (response.statusCode == 200) {
          _laadGebruikers(); // herlaad na verwijdering
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Verwijderen mislukt')),
          );
        }
      } catch (e) {
        print('Fout bij verwijderen: $e');
      }
    }
  }

  String _genereerGroepscode() {
    const karakters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final random = Random();
    return String.fromCharCodes(Iterable.generate(
      6,
      (_) => karakters.codeUnitAt(random.nextInt(karakters.length)),
    ));
  }

  void _toonUitnodiging() {
    final code = _genereerGroepscode();
    final link = 'https://mijnapp.nl/uitnodiging?code=$code';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Uitnodiging voor groep'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Groepscode: $code'),
            const SizedBox(height: 12),
            Text('Deel deze link:'),
            SelectableText(link, style: const TextStyle(color: Colors.blue)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Sluiten')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Groep beheren')),
      body: gebruikers.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: gebruikers.length,
              itemBuilder: (context, index) {
                final gebruiker = gebruikers[index];
                return ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(gebruiker['naam']),
                  subtitle: Text(gebruiker['email']),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.chat_bubble_outline),
                        onPressed: () {
                          // TODO: Voeg contactfunctionaliteit toe
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Contact nog niet geïmplementeerd')),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => _verwijderGebruiker(gebruiker['id']),
                      ),
                    ],
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _toonUitnodiging,
        child: const Icon(Icons.add),
      ),
    );
  }
}
