import 'package:flutter/material.dart';

class StartScherm extends StatelessWidget {
  const StartScherm({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Welkom')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/registratie');
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(60),
                textStyle: const TextStyle(fontSize: 20),
              ),
              child: const Text("Ik ben nieuw hier - Registreren"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/login');
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(60),
                backgroundColor: Colors.green,
                textStyle: const TextStyle(fontSize: 20),
              ),
              child: const Text("Ik heb al een account - Inloggen"),
            ),
          ],
        ),
      ),
    );
  }
}
