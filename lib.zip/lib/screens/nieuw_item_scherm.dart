import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spullen_delen/models/item.dart';

class NieuwItemScherm extends StatefulWidget {
  final Function(Item) onItemToegevoegd;
  final Item? bestaandItem;

  const NieuwItemScherm({
    super.key,
    required this.onItemToegevoegd,
    this.bestaandItem,
  });

  @override
  State<NieuwItemScherm> createState() => _NieuwItemSchermState();
}

class _NieuwItemSchermState extends State<NieuwItemScherm> {
  final _naamController = TextEditingController();
  final _infoController = TextEditingController();
  final _leenkostenController = TextEditingController();
  String? _imagePath;

  @override
  void initState() {
    super.initState();
    if (widget.bestaandItem != null) {
      _naamController.text = widget.bestaandItem!.naam;
      _infoController.text = widget.bestaandItem!.info ?? '';
      _leenkostenController.text = widget.bestaandItem!.leenkosten ?? '';
      _imagePath = widget.bestaandItem!.imagePath;
    }
  }

  Future<void> _selecteerFoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.camera);
    if (picked != null) {
      setState(() {
        _imagePath = picked.path;
      });
    }
  }

  void _opslaan() {
    final naam = _naamController.text.trim();
    if (naam.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Naam is verplicht')),
      );
      return;
    }

    final item = Item(
      id: widget.bestaandItem?.id, // Belangrijk voor bewerken!
      naam: naam,
      info: _infoController.text.trim().isEmpty
          ? null
          : _infoController.text.trim(),
      leenkosten: _leenkostenController.text.trim().isEmpty
          ? null
          : _leenkostenController.text.trim(),
      imagePath: _imagePath,
    );

    widget.onItemToegevoegd(item);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.bestaandItem != null
            ? 'Item bewerken'
            : 'Nieuw item toevoegen'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: _naamController,
              decoration: const InputDecoration(labelText: 'Naam (verplicht)'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _infoController,
              decoration: const InputDecoration(labelText: 'Extra info'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _leenkostenController,
              decoration: const InputDecoration(labelText: 'Leenkosten (optioneel)'),
              keyboardType: TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _selecteerFoto,
              icon: const Icon(Icons.camera_alt),
              label: const Text('Voeg foto toe'),
            ),
            if (_imagePath != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Image.file(File(_imagePath!), height: 150),
              ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _opslaan,
              child: const Text('Opslaan'),
            ),
          ],
        ),
      ),
    );
  }
}
