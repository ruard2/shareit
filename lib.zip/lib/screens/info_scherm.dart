// ✅ info_scherm.dart
import 'package:flutter/material.dart';

class InfoScherm extends StatelessWidget {
  const InfoScherm({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Info')),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(
          'Welkom bij de Spullen Delen app!\n\n'
          'Deze app is gemaakt voor gesloten groepen waar leden spullen kunnen delen.\n'
          'Je kunt je eigen spullen toevoegen, zoeken naar spullen van anderen, en leenverzoeken indienen.\n\n'
          'Beheerders kunnen groepen beheren en gebruikers goedkeuren.\n\n'
          'Let op: je kunt pas gebruikmaken van de app nadat een beheerder je heeft goedgekeurd.',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}