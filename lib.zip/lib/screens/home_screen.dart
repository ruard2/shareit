import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'mijn_spullen_scherm.dart';
import 'zoek_spullen_scherm.dart';
import 'groep_beheren_scherm.dart';
import 'instellingen_scherm.dart';
import 'info_scherm.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String gebruikersnaam = '';
  bool isBeheerder = false;

  @override
  void initState() {
    super.initState();
    _laadGebruikerVanServer();
  }

  Future<void> _laadGebruikerVanServer() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionId = prefs.getString('session_id');
      final userId = prefs.getString('user_id');
      final isAdmin = prefs.getBool('is_admin');
      final email = prefs.getString('email');

      print("🔍 Opgeslagen sessie-id: $sessionId");
      print("🔍 Opgeslagen user-id: $userId");
      print("🔍 Opgeslagen email: $email");
      print("🔍 isAdmin: $isAdmin");

      final response = await http.get(
        Uri.parse('http://10.0.2.2:8000/gebruikers/mij'),
        headers: {
          'Content-Type': 'application/json',
          'cookie': 'session_id=$sessionId',
        },
      );

      print("📡 Server response: ${response.statusCode}");
      print("📡 Body: ${response.body}");
      print("📡 Headers: ${response.headers}");

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          gebruikersnaam = data['naam'];
          isBeheerder = data['rol'] == 'beheerder' || data['naam'] == 'admin';
        });
        print('✅ Gebruiker geladen: $gebruikersnaam (beheerder: $isBeheerder)');
      } else {
        print('❌ Fout bij ophalen gebruiker. Status: ${response.statusCode}');
      }
    } catch (e) {
      print('❌ Fout in _laadGebruikerVanServer(): $e');
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hoofdmenu'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'Info',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const InfoScherm()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Instellingen',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const InstellingenScherm()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ZoekScherm()),
                );
              },
              child: const Text('Zoek spullen'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MijnSpullenScherm()),
                );
              },
              child: const Text('Mijn spullen'),
            ),
            const SizedBox(height: 16),
            if (isBeheerder)
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const GroepBeherenScherm()),
                  );
                },
                child: const Text('Groep beheren'),
              ),
          ],
        ),
      ),
    );
  }
}
