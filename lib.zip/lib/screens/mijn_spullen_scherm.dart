import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';

import 'nieuw_item_scherm.dart';
import 'item_detail_scherm.dart';
import '../models/item.dart';

class MijnSpullenScherm extends StatefulWidget {
  @override
  State<MijnSpullenScherm> createState() => _MijnSpullenSchermState();
}

class _MijnSpullenSchermState extends State<MijnSpullenScherm> {
  List<Item> mijnSpullen = [];

  @override
  void initState() {
    super.initState();
    _laadSpullen();
  }

  Future<void> _laadSpullen() async {
    try {
      final response = await http.get(Uri.parse('http://10.0.2.2:8000/spullen/mijn'));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setState(() {
          mijnSpullen = data.map((json) => Item.fromJson(json)).toList();
        });
      } else {
        print('Fout bij ophalen spullen: ${response.statusCode}');
      }
    } catch (e) {
      print('Fout bij laden spullen: $e');
    }
  }

  Future<void> _verwijderItem(Item item) async {
    final bevestiging = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bevestig verwijdering'),
        content: const Text('Weet je zeker dat je dit item wilt verwijderen?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuleren')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Verwijderen')),
        ],
      ),
    );

    if (bevestiging == true) {
      try {
        final response = await http.delete(Uri.parse('http://10.0.2.2:8000/spullen/${item.id}'));
        if (response.statusCode == 200) {
          _laadSpullen();
        } else {
          print('Item kon niet worden verwijderd: ${response.statusCode}');
        }
      } catch (e) {
        print('Fout bij verwijderen: $e');
      }
    }
  }

  void _openEditItem(Item item) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NieuwItemScherm(
          bestaandItem: item,
          onItemToegevoegd: (_) => _laadSpullen(),
        ),
      ),
    );
  }

  void _openNieuwItem() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NieuwItemScherm(
          onItemToegevoegd: (_) => _laadSpullen(),
        ),
      ),
    );
  }

  void _openDetail(Item item) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ItemDetailScherm(item: item),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mijn Spullen')),
      body: mijnSpullen.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: mijnSpullen.length,
              itemBuilder: (context, index) {
                final item = mijnSpullen[index];
                return ListTile(
                  leading: item.imagePath != null && item.imagePath!.isNotEmpty
                      ? Image.file(File(item.imagePath!), width: 50, height: 50, fit: BoxFit.cover)
                      : const Icon(Icons.inventory),
                  title: Text(item.naam),
                  subtitle: Text(item.info ?? ''),
                  onTap: () => _openDetail(item),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () => _openEditItem(item),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () => _verwijderItem(item),
                      ),
                    ],
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _openNieuwItem,
        child: const Icon(Icons.add),
      ),
    );
  }
}
