import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class RegistratieScherm extends StatefulWidget {
  const RegistratieScherm({Key? key}) : super(key: key);

  @override
  State<RegistratieScherm> createState() => _RegistratieSchermState();
}

class _RegistratieSchermState extends State<RegistratieScherm> {
  final _formKey = GlobalKey<FormState>();

  final naamController = TextEditingController();
  final emailController = TextEditingController();
  final telefoonController = TextEditingController();
  final adresController = TextEditingController();
  final pin1Controller = TextEditingController();
  final pin2Controller = TextEditingController();

  Future<void> _registreer() async {
    if (!_formKey.currentState!.validate()) return;

    final naam = naamController.text.trim();
    final email = emailController.text.trim();
    final telefoon = telefoonController.text.trim();
    final adres = adresController.text.trim();
    final pin = pin1Controller.text;

    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2:8000/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name': naam,
          'email': email,
          'phone': telefoon,
          'address': adres,
          'pin': pin,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final userId = data['id'];

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('user_id', userId.toString());

        _toonDialog("Registratie gelukt",
            "Wacht tot een beheerder je goedkeurt. Daarna kun je inloggen.");

        Navigator.pushReplacementNamed(context, '/login');
      } else {
        _toonDialog("Fout", "Registratie mislukt. Probeer opnieuw.");
      }
    } catch (e) {
      _toonDialog("Fout", "Er is een fout opgetreden: $e");
    }
  }

  void _toonDialog(String titel, String inhoud) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(titel),
        content: Text(inhoud),
        actions: [
          TextButton(
            child: const Text('OK'),
            onPressed: () => Navigator.pop(context),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registreren')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: naamController,
                decoration: const InputDecoration(labelText: 'Naam'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Naam is verplicht' : null,
              ),
              TextFormField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'E-mailadres'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'E-mail is verplicht' : null,
              ),
              TextFormField(
                controller: telefoonController,
                decoration: const InputDecoration(labelText: 'Telefoonnummer'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Telefoonnummer is verplicht' : null,
              ),
              TextFormField(
                controller: adresController,
                decoration: const InputDecoration(labelText: 'Adres (optioneel)'),
              ),
              TextFormField(
                controller: pin1Controller,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Pincode'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Pincode is verplicht' : null,
              ),
              TextFormField(
                controller: pin2Controller,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Herhaal pincode'),
                validator: (value) {
                  if (value != pin1Controller.text) {
                    return 'Pincodes komen niet overeen';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _registreer,
                child: const Text('Registreren'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
