import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/user_service.dart'; // aanroepen van backend-service

class InstellingenScherm extends StatefulWidget {
  const InstellingenScherm({super.key});

  @override
  State<InstellingenScherm> createState() => _InstellingenSchermState();
}

class _InstellingenSchermState extends State<InstellingenScherm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _naamController;
  late TextEditingController _adresController;
  late TextEditingController _pinController;

  String? _email;
  int? _userId;

  @override
  void initState() {
    super.initState();
    _naamController = TextEditingController();
    _adresController = TextEditingController();
    _pinController = TextEditingController();
    _laadGebruiker();
  }

  Future<void> _laadGebruiker() async {
    final prefs = await SharedPreferences.getInstance();
    _email = prefs.getString('email');
    _userId = prefs.getInt('user_id');
    _naamController.text = prefs.getString('name') ?? '';
    _adresController.text = prefs.getString('address') ?? '';
    _pinController.text = prefs.getString('pin') ?? '';
    setState(() {});
  }

  Future<void> _opslaanGebruiker() async {
    if (_userId == null) return;

    final success = await UserService.updateUser(
      userId: _userId!,
      name: _naamController.text,
      address: _adresController.text,
      pin: _pinController.text,
    );

    if (success) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setString('name', _naamController.text);
      prefs.setString('address', _adresController.text);
      prefs.setString('pin', _pinController.text);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Instellingen opgeslagen')),
      );
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Opslaan mislukt, probeer opnieuw')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_userId == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Instellingen')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Instellingen')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _naamController,
                decoration: const InputDecoration(labelText: 'Naam'),
                validator: (value) => value == null || value.isEmpty ? 'Naam is verplicht' : null,
              ),
              TextFormField(
                controller: _adresController,
                decoration: const InputDecoration(labelText: 'Adres (optioneel)'),
              ),
              TextFormField(
                controller: _pinController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Pincode'),
                validator: (value) => value == null || value.length < 4 ? 'Minimaal 4 cijfers' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _opslaanGebruiker();
                  }
                },
                child: const Text('Opslaan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
