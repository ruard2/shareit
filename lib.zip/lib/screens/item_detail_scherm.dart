import 'package:flutter/material.dart';
import 'dart:io'; // <-- essentieel voor File
import '../models/item.dart';

class ItemDetailScherm extends StatelessWidget {
  final Item item;

  const ItemDetailScherm({Key? key, required this.item}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(item.naam)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (item.imagePath != null && item.imagePath!.isNotEmpty)
              Image.file(
                File(item.imagePath!), // <-- werkt nu correct
                width: double.infinity,
                height: 200,
                fit: BoxFit.cover,
              ),
            const SizedBox(height: 16),
            Text('Naam: ${item.naam}', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            if (item.info != null) Text('Info: ${item.info!}'),
            if (item.leenkosten != null) Text('Leenkosten: ${item.leenkosten!}'),
          ],
        ),
      ),
    );
  }
}
