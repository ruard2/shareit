// ✅ zoek_spullen_scherm.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ZoekScherm extends StatefulWidget {
  const ZoekScherm({super.key});

  @override
  State<ZoekScherm> createState() => _ZoekSchermState();
}

class _ZoekSchermState extends State<ZoekScherm> {
  final TextEditingController _zoekController = TextEditingController();
  List<dynamic> _gevondenItems = [];

  void _zoekSpullen(String zoekterm) async {
    final response = await http.get(Uri.parse('http://10.0.2.2:8000/items/search?q=$zoekterm'));
    if (response.statusCode == 200) {
      setState(() {
        _gevondenItems = jsonDecode(response.body);
      });
    }
  }

  void _dienLeenVerzoekIn(dynamic item) {
    // TODO: Implementeer leenverzoek versturen naar backend
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Leenverzoek verstuurd voor ${item['name']}')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Zoek spullen')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _zoekController,
              decoration: const InputDecoration(labelText: 'Zoek naar een item'),
              onChanged: _zoekSpullen,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _gevondenItems.length,
                itemBuilder: (context, index) {
                  final item = _gevondenItems[index];
                  return ListTile(
                    title: Text(item['name'] ?? 'Onbekend'),
                    subtitle: Text(item['info'] ?? 'Geen info'),
                    trailing: ElevatedButton(
                      child: const Text('Leen'),
                      onPressed: () => _dienLeenVerzoekIn(item),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
