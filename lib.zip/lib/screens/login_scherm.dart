import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/user_service.dart'; // ✅ Blijft nodig

class LoginScherm extends StatefulWidget {
  const LoginScherm({super.key});

  @override
  _LoginSchermState createState() => _LoginSchermState();
}

class _LoginSchermState extends State<LoginScherm> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _pinController = TextEditingController();
  bool _isLoading = false;

  Future<void> _login() async {
    setState(() {
      _isLoading = true;
    });

    final url = Uri.parse('http://10.0.2.2:8000/login'); // ✅ Emulator URL
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': _emailController.text.trim(),
        'pin_code': _pinController.text.trim(),
      }),
    );

    setState(() {
      _isLoading = false;
    });

    if (response.statusCode == 200) {
      final userData = jsonDecode(response.body);

      final prefs = await SharedPreferences.getInstance();
      prefs.setString('user_id', userData['id']?.toString() ?? '');
      prefs.setString('email', userData['email'] ?? '');
      prefs.setBool('is_admin', userData['is_admin'] ?? false);
      prefs.setBool('is_approved', userData['is_approved'] ?? false);

      // ⬇️ Session cookie opslaan
      final setCookie = response.headers['set-cookie'];
      if (setCookie != null) {
        final sessionMatch = RegExp(r'session_id=([^;]+)').firstMatch(setCookie);
        if (sessionMatch != null) {
          final sessionId = sessionMatch.group(1);
          await prefs.setString('session_id', sessionId ?? '');
          print('✅ session_id opgeslagen: $sessionId');
        } else {
          print('❌ Geen geldige session_id gevonden in cookie');
        }
      } else {
        print('❌ Geen set-cookie header ontvangen');
      }

      // ✅ Gebruiker laden via Provider na login
      final gebruiker = await UserService.haalHuidigeGebruikerOp();
      if (gebruiker != null) {
        print('✅ Gebruiker geladen: ${gebruiker.email}');
      } else {
        print('❌ Gebruiker ophalen mislukt na login');
      }

      Navigator.pushReplacementNamed(context, '/home');
    } else if (response.statusCode == 401) {
      _showMessage("Ongeldige inloggegevens");
    } else if (response.statusCode == 403) {
      _showMessage("Je registratie is ontvangen, maar je moet nog worden goedgekeurd door de beheerder.");
    } else {
      _showMessage("Er is iets misgegaan. Probeer opnieuw.");
    }
  }

  void _loginAlsBeheerder() {
    _emailController.text = 'beheerder@app.com';
    _pinController.text = '0000';
    _login();
  }

  void _showMessage(String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Let op"),
        content: Text(message),
        actions: [
          TextButton(
            child: const Text("OK"),
            onPressed: () => Navigator.of(context).pop(),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Inloggen")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              controller: _pinController,
              decoration: const InputDecoration(labelText: 'Pincode'),
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 24),
            if (_isLoading)
              const CircularProgressIndicator()
            else
              Column(
                children: [
                  ElevatedButton(
                    onPressed: _login,
                    child: const Text('Inloggen'),
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: _loginAlsBeheerder,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                    child: const Text('Inloggen als beheerder'),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
