import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// Schermen
import 'screens/home_screen.dart';
import 'screens/login_scherm.dart';
import 'screens/registratie_scherm.dart';
import 'screens/zoek_spullen_scherm.dart';
import 'screens/mijn_spullen_scherm.dart';
import 'screens/info_scherm.dart';
import 'screens/instellingen_scherm.dart';
import 'screens/groep_beheren_scherm.dart';
import 'screens/start_scherm.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Widget? _startScherm;

  @override
  void initState() {
    super.initState();
    _bepaalStartscherm();
  }

  Future<void> _bepaalStartscherm() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('user_id');

    if (userId == null) {
      // Nog niet ingelogd/geregistreerd
      setState(() {
        _startScherm = const StartScherm();
      });
    } else {
      try {
        final response = await http.get(
          Uri.parse('http://10.0.2.2:8000/gebruikers/mij'),
          headers: {
            'Content-Type': 'application/json',
            'user-id': userId,
          },
        );

        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          final isApproved = data['is_approved'] == true;

          setState(() {
            _startScherm = isApproved ? const HomeScreen() : const StartScherm();
          });
        } else {
          // Mislukt om goedgekeurde gebruiker op te halen
          print('Kan gebruiker niet ophalen. Statuscode: ${response.statusCode}');
          setState(() {
            _startScherm = const StartScherm();
          });
        }
      } catch (e) {
        // Netwerkfout of andere fout
        print('Fout bij ophalen gebruiker: $e');
        setState(() {
          _startScherm = const StartScherm();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Spullen Delen',
      theme: ThemeData(primarySwatch: Colors.teal),
      routes: {
        '/home': (context) => const HomeScreen(),
        '/login': (context) => const LoginScherm(),
        '/registratie': (context) => const RegistratieScherm(),
        '/zoek': (context) => const ZoekScherm(),
        '/mijnspullen': (context) => MijnSpullenScherm(),
        '/info': (context) => const InfoScherm(),
        '/instellingen': (context) => const InstellingenScherm(),
        '/beheer': (context) => const GroepBeherenScherm(),
      },
      home: _startScherm == null
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : _startScherm!,
    );
  }
}
