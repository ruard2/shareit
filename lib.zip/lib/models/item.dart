class Item {
  final int? id;
  final String naam;
  final String? info;
  final String? leenkosten;
  final String? imagePath;

  Item({
    this.id,
    required this.naam,
    this.info,
    this.leenkosten,
    this.imagePath,
  });

  factory Item.fromJson(Map<String, dynamic> json) {
    return Item(
      id: json['id'],
      naam: json['naam'],
      info: json['info'],
      leenkosten: json['leenkosten'],
      imagePath: json['imagePath'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'naam': naam,
      'info': info,
      'leenkosten': leenkosten,
      'imagePath': imagePath,
    };
  }
}
